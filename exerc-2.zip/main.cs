using System;

namespace ConverterIdade
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Digite a idade da pessoa em dias:");
            int idadeEmDias = Convert.ToInt32(Console.ReadLine());

            int anos = idadeEmDias / 365;
            int meses = (idadeEmDias % 365) / 30;
            int dias = (idadeEmDias % 365) % 30;

            Console.WriteLine($"A idade corresponde a {anos} anos, {meses} meses e {dias} dias.");

            Console.WriteLine("Pressione qualquer tecla para sair.");
            Console.ReadKey();
        }
    }
}
